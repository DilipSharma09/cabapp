import React, { Component } from "react";
import axios from "axios";
import "antd/dist/antd.css";
import "./DriverDashboard.css";
import Paper from 'material-ui/Paper';
import Avatar from 'material-ui/Avatar';
// import SignInImage from './Images/download.jpg';
import { Form, Input, Button } from "antd";
import { locales } from "moment";

const stylePaper = {
    height: 'auto',
    width: '50%',
    // background: '#f8f8f9',
    position: 'relative',
    marginLeft: '25%',
    marginTop: '20px',
    padding: '20px 40px'
};



// const bookRideHeader={
//     display: 'flex'
//     border-top-right-radius: 10px;
//     justify-content: center;
//     padding: 10px;
//     /* background: red; */
//     border-top-left-radius: 10px;
//     background: #e5e5e5;
//     border-bottom: 1px solid rgb(193, 193, 223);
// }


const styleText = {
    marginLeft: '25%',
    marginTop: '-50px',
    fontSize: '1.71429rem',
    fontFamily: 'ff-clan-web-pro,"Helvetica Neue",Helvetica,sans-serif!important',
    fontWeight: '400'
};

const FormItem = Form.Item;

class DriverDashboard extends Component {
    state = {
        res: {},
        res_received: false,
        data: [
            { 'id': 1, 1: 'Date', 2: 'Source', 3: 'Destination', 4: 'Status', 5: 'Payment' },
            { 'id': 2, 1: '2019/09/18 1:06:24', 2: 'sipcot', 3: 'padur', 4: '0', 5: 'card' },
            { 'id': 3, 1: '2019/09/18 1:06:24', 2: 'sip', 3: 'goa', 4: '0', 5: 'online' }
        ],
        tripsAvailableData: [
            { 'id': 1, 1: 'Passenger_ID', 2: 'Source', 3: 'Destination', 4: '' },
            { 'id': 2, 1: '2019/09/18 1:06:24', 2: 'sipcot', 3: 'padur', 4: '' },
            { 'id': 3, 1: '2019/09/18 1:06:24', 2: 'sip', 3: 'goa', 4: '' }
        ]
    };

    handleSubmit = e => {
        e.preventDefault();
        this.props.form.validateFields((err, fieldsValue) => {
            if (!err) {
                const values = {
                    ...fieldsValue,
                    role: 'user'
                };
                //delete values[""];
                console.log("Received values of form: ", values);
                axios
                    .post("https://api.crossfire37.hasura-app.io/signup", {
                        "user": {
                            "provider": "username",
                            "data": {
                                "username": values.firstname,
                                "password": values.password
                            }
                        },
                        "role": values.role,
                        "firstname": values.firstname,
                        "lastname": values.lastname
                    }
                    )
                    .then(response => {
                        console.log(response);
                        localStorage.setItem('AuthToken', response.data.auth_token)
                        this.setState({ res: response.data });
                        this.setState({ res_received: true });
                    })
                    .catch(error => {
                        alert("ERROR: User name already exists!");
                        this.setState({ res: 'test' });
                        console.log(error);
                    });
            }
        });
    };

    render() {
        const { getFieldDecorator } = this.props.form;
        let result = null;
        if (true) {
            //  alert('Sign Up Succesful! Please go to "Ride" to book your ride.');
            console.log(this.state.res_recieved);
        }

        let tableStyle = {
            align: "center"
        };

        let list = this.state.data.map(p => {
            return (
                <tr className="grey2 border-top" key={p.id}>
                    {Object.keys(p).filter(k => k !== 'id').map(k => {
                        return (
                            <td className="grey1" key={p.id + '' + k}>
                                <div suppressContentEditableWarning="true" contentEditable="true" value={k} >
                                    {p[k]}
                                </div>
                            </td>
                        );
                    })}
                </tr>
            );
        });

        let tripsAvailable = this.state.tripsAvailableData.map(p => {
            return (
                <tr className="grey2 border-top" key={p.id}>
                    {Object.keys(p).filter(k => k !== 'id').map(k => {
                        let t;
                        if (p[1] != "Passenger_ID" && k == 4) {
                            t = <button>Accept</button>
                        } else {
                            t = <div suppressContentEditableWarning="true" contentEditable="true" value={k} >
                                {p[k]}
                            </div>
                        }
                        return (
                            <td className="grey1" key={p.id + '' + k}>
                                {t}
                            </td>
                        );
                    })
                    }
                </tr>
            );
        });


        return (
            <div>
                <h2 className="pageheader">Driver Dashboard</h2>
                <Paper style={stylePaper}>
                    <div className="bookRideSection">
                        <div className="bookRideheader">
                            <span>Trips Available</span>
                        </div>
                        <div className="bookRideBody">
                            <fieldset className="step-4">
                                <div className="schedule padd-lr">
                                    <table cellSpacing="15" id="mytable" style={tableStyle}>
                                        <tbody>{tripsAvailable}</tbody>
                                    </table>
                                </div>
                            </fieldset>
                        </div>
                    </div>
                    <div className="bookRideSection bookRideheaderSectionOne">
                        <div className="bookRideheader ">
                            <span>Enroute to Passeneger</span>
                        </div>
                        <div className="enRouteBody">
                            <div className="enrouteBodyData">
                                <label>Passeneger: Passeneger</label>
                            </div>
                            <div className="enrouteBodyData">
                                <label>Destination: padur </label>
                            </div>
                            <div className="enrouteBodyData">
                                <Button
                                    type="primary"
                                >
                                    Start
                                </Button>
                            </div>
                        </div>
                        <div className="enRouteBodyTwo">
                            <div className="enrouteBodyData">
                                <label>Phone: 9857903455</label>
                            </div>
                            <div className="enrouteBodyData">
                                <Button
                                    type="primary"
                                >
                                    Cancel
                                </Button>
                            </div>
                        </div>
                    </div>
                    <div className="bookRideSection bookRideheaderSectionOne">
                        <div className="bookRideheader ">
                            <span>Enroute to Destiination</span>
                        </div>
                        <div className="enRouteBody">
                            <div className="enrouteBodyData">
                                <label>Passeneger: Passeneger</label>
                            </div>
                            <div className="enrouteBodyData">
                                <label>Destination: padur </label>
                            </div>
                            <div className="enrouteBodyData">
                                <Button
                                    type="primary"
                                >
                                    End Trip
                                </Button>
                            </div>
                        </div>
                        <div className="enRouteBodyTwo">
                            <div className="enrouteBodyData">
                                <label>Phone: 9857903455</label>
                            </div>
                        </div>
                    </div>
                    <div className="bookRideSection">
                        <div className="bookRideheader">
                            <span>Last 5 Trip</span>
                        </div>
                        <div className="bookRideBody">
                            <fieldset className="step-4">
                                <div className="schedule padd-lr">
                                    <table cellSpacing="15" id="mytable" style={tableStyle}>
                                        <tbody>{list}</tbody>
                                    </table>
                                </div>
                            </fieldset>
                        </div>
                    </div>
                </Paper>
            </div>
        );
    }
}

const Sign_up = Form.create()(DriverDashboard);

export default Sign_up;
