import React, { Component } from "react";
import axios from "axios";
import "antd/dist/antd.css";
// import "./UserSignIn.css";
import Paper from 'material-ui/Paper';
import Avatar from 'material-ui/Avatar';
// import SignInImage from './Images/download.jpg';
import { Form, Input, Button } from "antd";
import { locales } from "moment";
import { Redirect } from 'react-router-dom'

const stylePaper = {
    height: 'auto',
    width: '400px',
    background: '#f8f8f9',
    position: 'relative',
    marginLeft: '35%',
    marginTop: '70px'
};

const styleText = {
    marginLeft: '100px',
    marginTop: '-50px',
    fontSize: '1.71429rem',
    fontFamily: 'ff-clan-web-pro,"Helvetica Neue",Helvetica,sans-serif!important',
    fontWeight: '400'
};

const FormItem = Form.Item;

class Login extends Component {
    state = {
        res: {},
        res_received: false,
        optionsState: 'driver'
    };

    handleSubmit = e => {
        e.preventDefault();
        this.props.form.validateFields((err, fieldsValue) => {
            if (!err) {
                const values = {
                    ...fieldsValue,
                };
                console.log("Received values of form: ", values);
                axios
                    .get(`http://13.233.219.169:8080/registration/api/${this.state.optionsState}/login?username=${values.username}&password=${values.password}`
                    )
                    .then(response => {
                        console.log(response);
                        localStorage.setItem('AuthToken', response.data.auth_token)
                        localStorage.setItem('userData', { status: 0 });
                        //this.setState({ res: response.data });
                        this.setState({ res_received: true });
                    })
                    .catch(error => {
                        alert("ERROR: wrong credentials entered!");
                        console.log(error);
                    });
            }
        });
    };

    render() {
        const { getFieldDecorator } = this.props.form;
        let result = null;
        if (this.state.res_received) {
            alert('Login Succesful!');
            console.log(this.state.res_recieved);
            if (this.state.optionsState == 'driver') {
                return <Redirect to='/DriverDashboard' />
            }
            return <Redirect to='/PassengerDashboard' />
        }
        const optionsState = this.state.optionsState;
        return (
            <Paper style={stylePaper}>
                <Form onSubmit={this.handleSubmit} className="signup-form">
                    <div style={{ marginLeft: '0px', marginBottom: '40px' }}>
                        {/* <Avatar src={SignInImage} size='80px' />   */}
                        <div style={styleText}>
                            CAB APP
                        </div>
                    </div>
                    <FormItem>
                        {getFieldDecorator("username", {
                            rules: [{ required: true, message: "Please input your UserName!" }]
                        })(<label>User Name <Input placeholder="User Name" /> </label>)}
                    </FormItem>
                    <FormItem>
                        {getFieldDecorator("password", {
                            rules: [
                                { required: true, message: "Please input your Password!" },
                                { min: 8, message: "Minimum password length is 8 characters" }
                            ]
                        })(<label>Password <Input type="password" placeholder="Password" /></label>)}
                    </FormItem>
                    <FormItem>
                        <label>Login As <select
                            onChange={(value) => {
                                this.setState({ optionsState: value.target.value })
                            }} value={optionsState}>
                            <option value="driver">Driver</option>
                            <option value="passenger">Passenger</option>
                        </select></label>
                    </FormItem>
                    <FormItem>
                        <Button
                            type="primary"
                            htmlType="submit"
                        >
                            LOGIN
                        </Button>
                    </FormItem>
                    <div style={{ display: 'flex' }}>
                        <Button
                            type="primary"
                            href="/DriverSignup"
                        >
                            Driver Registration
                        </Button>
                        <Button
                            type="primary"
                            href="/PassengerSignup"
                        >
                            Passenger Registration
                        </Button>
                    </div>
                    {result}
                </Form>
            </Paper>
        );
    }
}

const Sign_up = Form.create()(Login);

export default Sign_up;
