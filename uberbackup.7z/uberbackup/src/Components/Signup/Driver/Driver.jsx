import React, { Component } from "react";
import axios from "axios";
import "antd/dist/antd.css";
// import "./UserSignIn.css";
import Paper from 'material-ui/Paper';
import Avatar from 'material-ui/Avatar';
// import SignInImage from './Images/download.jpg';
import { Form, Input, Button } from "antd";
import { locales } from "moment";
import { Redirect } from 'react-router-dom'

const stylePaper = {
    height: 'auto',
    width: '400px',
    background: '#f8f8f9',
    position: 'relative',
    marginLeft: '35%',
    marginTop: '70px'
};

const styleText = {
    marginLeft: '100px',
    marginTop: '-50px',
    fontSize: '1.71429rem',
    fontFamily: 'ff-clan-web-pro,"Helvetica Neue",Helvetica,sans-serif!important',
    fontWeight: '400'
};

const FormItem = Form.Item;

class DriverSignup extends Component {
    state = {
        res: {},
        res_received: false
    };

    handleSubmit = e => {
        e.preventDefault();
        this.props.form.validateFields((err, fieldsValue) => {
            if (!err) {
                const values = {
                    ...fieldsValue
                };
                //delete values[""];
                console.log("Received values of form: ", values);
                axios
                    .post("http://13.233.219.169:8080/registration/api/driver", {
                        "d_FIRST_NAME": values.firstname,
                        "d_LAST_NAME": values.lastname,
                        "d_USERNAME": values.username,
                        "d_PASSWORD": values.password,
                        "d_VEHICLE_NO": values.vehicleno,
                        "d_PHONE_NO": values.phoneno,
                        "d_SOURCE": values.source,
                        "d_STATUS": values.status
                    }
                    )
                    .then(response => {
                        console.log(response);
                        // localStorage.setItem('AuthToken', response.data.auth_token)
                        this.setState({ res: response.data });
                        this.setState({ res_received: true });
                    })
                    .catch(error => {
                        alert("ERROR: User name already exists!");
                        // this.setState({ res: 'test' });
                        console.log(error);
                    });
            }
        });
    };

    render() {
        const { getFieldDecorator } = this.props.form;
        let result = null;
        if (this.state.res_received) {
            alert('Sign Up Succesful!');
            console.log(this.state.res_recieved);
            return <Redirect to='/login' />
        }

        return (
            <Paper style={stylePaper}>

                <Form onSubmit={this.handleSubmit} className="signup-form">
                    <div style={{ marginLeft: '0px', marginBottom: '40px' }}>
                        {/* <Avatar src={SignInImage} size='80px' />   */}
                        <div style={styleText}>
                            Ride With Uber
                        </div>
                    </div>
                    <FormItem>
                        {getFieldDecorator("firstname", {
                            rules: [{ required: true, message: "Please input your First Name!" }]
                        })(<Input placeholder="First Name" />)}
                    </FormItem>
                    <FormItem>
                        {getFieldDecorator("lastname", {
                            rules: [{ required: true, message: "Please input your Last Name!" }]
                        })(<Input placeholder="Last Name" />)}
                    </FormItem>
                    <FormItem>
                        {getFieldDecorator("username", {
                            rules: [{ required: true, message: "Please input your User Name!" }]
                        })(<Input placeholder="User Name" />)}
                    </FormItem>
                    <FormItem>
                        {getFieldDecorator("password", {
                            rules: [
                                { required: true, message: "Please input your Password!" },
                                { min: 8, message: "Minimum password length is 8 characters" }
                            ]
                        })(<Input type="password" placeholder="Password" />)}
                    </FormItem>
                    <FormItem>
                        {getFieldDecorator("source", {
                            rules: [{ required: true, message: "Please input your Source!" }]
                        })(<Input placeholder="Source" />)}
                    </FormItem>
                    <FormItem>
                        {getFieldDecorator("status", {
                            rules: [{ required: true, message: "Please input your Status!" }]
                        })(<Input placeholder="Status" />)}
                    </FormItem>
                    <FormItem>
                        {getFieldDecorator("vehicleno", {
                            rules: [{ required: true, message: "Please input your Vehicle No!" }]
                        })(<Input placeholder="Vehicle No" />)}
                    </FormItem>
                    <FormItem>
                        {getFieldDecorator("phoneno", {
                            rules: [{ required: true, message: "Please input your Phone No!" }]
                        })(<Input placeholder="Phone No" />)}
                    </FormItem>
                    <FormItem>
                        <div style={{ display: 'flex' }}>
                            <Button
                                type="primary"
                                htmlType="submit"
                                className="signup-form-button"
                            >
                                Register
                            </Button>
                            <Button
                                type="primary"
                                href="/PassengerSignup"
                            >
                                cancel
                            </Button>
                        </div>
                    </FormItem>
                    {result}
                </Form>
            </Paper>
        );
    }
}

const Sign_up = Form.create()(DriverSignup);

export default Sign_up;
